// === Charger les tenues depuis localStorage ===
function chargerTenues() {
    const tenues = JSON.parse(localStorage.getItem("tenues") || "[]");
    const liste = document.getElementById("liste-tenues");
    liste.innerHTML = "";
  
    tenues.forEach((tenue, index) => {
      const div = document.createElement("div");
      div.className = "tenue-card";
      div.innerHTML = `
        <img src="${tenue.image}" alt="${tenue.nom}">
        <p><strong>${tenue.nom}</strong><br><em>${tenue.genre} - ${tenue.style}</em></p>
        <button onclick="modifierTenue(${index})">✏️ Modifier</button>
        <button onclick="supprimerTenue(${index})">🗑️ Supprimer</button>
      `;
      liste.appendChild(div);
    });
  }
  
  // === Ajouter une nouvelle tenue ===
  function ajouterTenue() {
    const genre = document.getElementById("genre-select").value;
    const style = document.getElementById("style-select").value;
    const nom = document.getElementById("nom-tenue").value;
    const imageInput = document.getElementById("image-tenue");
    const file = imageInput.files[0];
  
    if (!genre || !style || !nom || !file) {
      alert("Veuillez remplir tous les champs.");
      return;
    }
  
    const reader = new FileReader();
    reader.onload = function (e) {
      const imageData = e.target.result;
  
      // Crée l'objet de la tenue
      const tenue = {
        genre: genre,
        style: style,
        nom: nom,
        image: imageData
      };
  
      // Récupérer les tenues déjà stockées
      const tenues = JSON.parse(localStorage.getItem("tenues")) || [];
  
      // Ajouter la nouvelle tenue
      tenues.push(tenue);
  
      // Enregistrer dans localStorage
      localStorage.setItem("tenues", JSON.stringify(tenues));
  
      // Confirmer
      document.getElementById("message-success").innerText = "✅ Tenue ajoutée avec succès !";
  
      // Réinitialiser les champs
      document.getElementById("genre-select").value = "";
      document.getElementById("style-select").value = "";
      document.getElementById("nom-tenue").value = "";
      imageInput.value = "";
      document.getElementById("nom-fichier").innerText = "";
    };
  
    reader.readAsDataURL(file);
  }
  
  // === Supprimer une tenue ===
  function supprimerTenue(index) {
    const tenues = JSON.parse(localStorage.getItem("tenues") || "[]");
    if (confirm("Supprimer cette tenue ?")) {
      tenues.splice(index, 1);
      localStorage.setItem("tenues", JSON.stringify(tenues));
      chargerTenues();
    }
  }
  
  // === Modifier une tenue ===
  function modifierTenue(index) {
    const tenues = JSON.parse(localStorage.getItem("tenues") || "[]");
    const tenue = tenues[index];
  
    document.getElementById("genre-select").value = tenue.genre;
    document.getElementById("style-select").value = tenue.style;
    document.getElementById("nom-tenue").value = tenue.nom;
  
    const form = document.getElementById("ajout-tenue-form");
    form.onsubmit = function (e) {
      e.preventDefault();
  
      const genre = document.getElementById("genre-select").value;
      const style = document.getElementById("style-select").value;
      const nom = document.getElementById("nom-tenue").value;
      const imageInput = document.getElementById("image-tenue");
  
      const updateAndSave = (imageData) => {
        tenue.genre = genre;
        tenue.style = style;
        tenue.nom = nom;
        if (imageData) tenue.image = imageData;
  
        tenues[index] = tenue;
        localStorage.setItem("tenues", JSON.stringify(tenues));
        chargerTenues();
        form.reset();
        form.onsubmit = (event) => {
          event.preventDefault();
          ajouterTenue();
        };
      };
  
      if (imageInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
          updateAndSave(e.target.result);
        };
        reader.readAsDataURL(imageInput.files[0]);
      } else {
        updateAndSave(); // pas de nouvelle image
      }
    };
  }
  
  // === Vérifier mot de passe ===
  function verifierMotDePasse() {
    const pass = document.getElementById("admin-password").value;
    if (pass === "mode123") {
      window.location.href = "admin.html"; // Redirige vers admin après login
    } else {
      alert("Mot de passe incorrect");
    }
  }
  
  // === Aller vers page principale ===
  function allerVersMain() {
    window.location.href = "main.html#mainSite";
  }
  
  // === Charger dès que la page est prête ===
  window.addEventListener("DOMContentLoaded", () => {
    chargerTenues();
    const form = document.getElementById("ajout-tenue-form");
    if (form) {
      form.onsubmit = function (e) {
        e.preventDefault();
        ajouterTenue();
      };
    }
  });
  function afficherTenuesAdmin() {
    const liste = document.getElementById("liste-tenues");
    liste.innerHTML = "";
  
    const tenues = JSON.parse(localStorage.getItem("tenues") || "[]");
  
    tenues.forEach((t, index) => {
      const item = document.createElement("div");
      item.className = "tenue-admin-card";
  
      item.innerHTML = `
        <img src="${t.image}" alt="${t.nom}" class="admin-image">
        <p><strong>${t.nom}</strong> - ${t.genre} / ${t.style}</p>
        <button class="delete-btn" onclick="supprimerTenueAdmin(${index})">🗑️ Supprimer</button>
      `;
      liste.appendChild(item);
    });
  }
  function supprimerTenueAdmin(index) {
    const tenues = JSON.parse(localStorage.getItem("tenues") || "[]");
    tenues.splice(index, 1);
    localStorage.setItem("tenues", JSON.stringify(tenues));
    afficherTenuesAdmin(); // Mise à jour après suppression
  }
  